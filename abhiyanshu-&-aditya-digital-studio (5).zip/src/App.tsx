import React, { useState } from 'react';
import { Page, Language, ContactMessage } from './types';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { GallerySection } from './components/GallerySection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CustomizeModal } from './components/CustomizeModal';
import { Phone, MessageCircle } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [language, setLanguage] = useState<Language>('hi'); // Default Hindi as requested in details, toggleable to English

  // Website details state
  const [websiteName, setWebsiteName] = useState<string>('Abhiyanshu & Aditya Digital Studio');
  const [mobileNumber, setMobileNumber] = useState<string>('+91 78087 50089');
  const [emailAddress, setEmailAddress] = useState<string>('abhiyanshuraj146@gmail.com');
  const [address] = useState<string>('Tech Park, Sector 62, Noida, Delhi NCR, India');

  const [selectedService, setSelectedService] = useState<string>('');
  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>([]);

  const handleSendMessage = (msg: ContactMessage) => {
    setContactMessages((prev) => [msg, ...prev]);
  };

  const handleSelectServiceForInquiry = (serviceName: string) => {
    setSelectedService(serviceName);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Sticky Top Header Navigation */}
      <Navbar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        language={language}
        setLanguage={setLanguage}
        websiteName={websiteName}
        mobileNumber={mobileNumber}
        onOpenSettings={() => setSettingsOpen(true)}
      />

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <>
            <HeroSection
              setCurrentPage={setCurrentPage}
              language={language}
              websiteName={websiteName}
              mobileNumber={mobileNumber}
            />
            <AboutSection
              language={language}
              setCurrentPage={setCurrentPage}
              websiteName={websiteName}
            />
            <ServicesSection
              language={language}
              setCurrentPage={setCurrentPage}
              onSelectServiceForInquiry={handleSelectServiceForInquiry}
            />
            <GallerySection language={language} />
            <ContactSection
              language={language}
              mobileNumber={mobileNumber}
              emailAddress={emailAddress}
              address={address}
              preselectedService={selectedService}
              onSendMessage={handleSendMessage}
            />
          </>
        )}

        {currentPage === 'about' && (
          <AboutSection
            language={language}
            setCurrentPage={setCurrentPage}
            websiteName={websiteName}
          />
        )}

        {currentPage === 'services' && (
          <ServicesSection
            language={language}
            setCurrentPage={setCurrentPage}
            onSelectServiceForInquiry={handleSelectServiceForInquiry}
          />
        )}

        {currentPage === 'gallery' && <GallerySection language={language} />}

        {currentPage === 'contact' && (
          <ContactSection
            language={language}
            mobileNumber={mobileNumber}
            emailAddress={emailAddress}
            address={address}
            preselectedService={selectedService}
            onSendMessage={handleSendMessage}
          />
        )}
      </main>

      {/* Floating Sticky Quick Action Bar (Mobile & Tablet) */}
      <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 flex items-center gap-3">
        <a
          href={`https://wa.me/${mobileNumber.replace(/[^0-9]/g, '')}`}
          target="_blank"
          rel="noreferrer"
          className="p-3.5 rounded-full bg-emerald-600 text-white shadow-xl shadow-emerald-600/30 hover:scale-110 transition-transform flex items-center justify-center cursor-pointer"
          title="WhatsApp Chat"
        >
          <MessageCircle className="w-6 h-6" />
        </a>

        <a
          href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`}
          className="p-3.5 rounded-full bg-blue-600 text-white shadow-xl shadow-blue-600/30 hover:scale-110 transition-transform flex items-center justify-center cursor-pointer"
          title="Call Now"
        >
          <Phone className="w-6 h-6" />
        </a>
      </div>

      {/* Settings Modal */}
      <CustomizeModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        language={language}
        websiteName={websiteName}
        setWebsiteName={setWebsiteName}
        mobileNumber={mobileNumber}
        setMobileNumber={setMobileNumber}
        emailAddress={emailAddress}
        setEmailAddress={setEmailAddress}
      />

      {/* Footer with exact required copyright & attribution */}
      <Footer
        setCurrentPage={setCurrentPage}
        language={language}
        websiteName={websiteName}
        mobileNumber={mobileNumber}
        emailAddress={emailAddress}
      />
    </div>
  );
}
