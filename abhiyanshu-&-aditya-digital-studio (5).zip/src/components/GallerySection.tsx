import React, { useState } from 'react';
import { Image as ImageIcon, Maximize2, Tag, Filter, X } from 'lucide-react';
import { Language, GalleryItem } from '../types';
import { galleryData } from '../data/websiteData';

interface GallerySectionProps {
  language: Language;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ language }) => {
  const isHi = language === 'hi';
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  const categories = [
    { id: 'all', labelEn: 'All Projects', labelHi: 'सभी प्रोजेक्ट्स' },
    { id: 'web', labelEn: 'Web Designs', labelHi: 'वेब डिज़ाइन' },
    { id: 'mobile', labelEn: 'Mobile UI', labelHi: 'मोबाइल यूआई' },
    { id: 'ui', labelEn: 'UI/UX', labelHi: 'यूआई/यूएक्स' },
    { id: 'branding', labelEn: 'Branding', labelHi: 'ब्रांडिंग' },
  ];

  const filteredItems =
    activeCategory === 'all'
      ? galleryData
      : galleryData.filter((item) => item.category === activeCategory);

  return (
    <div className="bg-slate-900 text-slate-100 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider">
            <ImageIcon className="w-3.5 h-3.5" />
            <span>{isHi ? 'फोटो एवं प्रोजेक्ट गैलरी' : 'Photo Gallery'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            {isHi ? 'हमारे द्वारा निर्मित वेबसाइट्स का प्रदर्शन' : 'Explore Our Web Design Showcase'}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            {isHi
              ? 'अभियांशु कुमार और आदित्य कुमार द्वारा बनाए गए विभिन्न रिस्पॉन्सिव और आधुनिक वेब प्रोजेक्ट्स।'
              : 'A curated collection of modern, responsive websites designed by Abhiyanshu Kumar & Aditya Kumar.'}
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => {
            const active = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                  active
                    ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                <span>{isHi ? cat.labelHi : cat.labelEn}</span>
              </button>
            );
          })}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedImage(item)}
              className="group bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 hover:border-blue-500/50 transition-all duration-300 hover:-translate-y-1 shadow-lg cursor-pointer"
            >
              {/* Image Container */}
              <div className="relative aspect-video overflow-hidden bg-slate-900">
                <img
                  src={item.image}
                  alt={item.titleEn}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />

                <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold flex items-center gap-2 shadow-lg">
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>{isHi ? 'बड़ा करके देखें' : 'View Full Image'}</span>
                  </div>
                </div>

                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-slate-900/80 backdrop-blur-md text-slate-200 text-[10px] font-semibold uppercase tracking-wider border border-slate-700">
                  {isHi ? item.categoryLabelHi : item.categoryLabelEn}
                </div>
              </div>

              {/* Card Details */}
              <div className="p-5 space-y-3">
                <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                  {isHi ? item.titleHi : item.titleEn}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {isHi ? item.descriptionHi : item.descriptionEn}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-2">
                  {item.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800"
                    >
                      <Tag className="w-2.5 h-2.5 text-blue-400" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {selectedImage && (
          <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md p-4 sm:p-6 flex items-center justify-center animate-in fade-in">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl relative">
              {/* Modal Top Bar */}
              <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
                <div>
                  <h3 className="text-base font-bold text-white">
                    {isHi ? selectedImage.titleHi : selectedImage.titleEn}
                  </h3>
                  <p className="text-xs text-blue-400 font-medium">
                    {isHi ? selectedImage.categoryLabelHi : selectedImage.categoryLabelEn}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedImage(null)}
                  className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Image View */}
              <div className="p-4 overflow-y-auto flex-1 bg-black/40 flex flex-col items-center justify-center">
                <img
                  src={selectedImage.image}
                  alt={selectedImage.titleEn}
                  className="max-h-[60vh] w-auto object-contain rounded-xl border border-slate-800"
                />

                <div className="mt-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800 max-w-2xl w-full space-y-2 text-center">
                  <p className="text-xs sm:text-sm text-slate-200">
                    {isHi ? selectedImage.descriptionHi : selectedImage.descriptionEn}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    {isHi
                      ? 'वेब डिज़ाइनर: अभियान्शु कुमार एवं आदित्य कुमार'
                      : 'Designed By: Abhiyanshu Kumar & Aditya Kumar'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
