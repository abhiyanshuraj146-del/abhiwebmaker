import React, { useState } from 'react';
import { Settings, X, Save, RefreshCw } from 'lucide-react';
import { Language } from '../types';

interface CustomizeModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  websiteName: string;
  setWebsiteName: (val: string) => void;
  mobileNumber: string;
  setMobileNumber: (val: string) => void;
  emailAddress: string;
  setEmailAddress: (val: string) => void;
}

export const CustomizeModal: React.FC<CustomizeModalProps> = ({
  isOpen,
  onClose,
  language,
  websiteName,
  setWebsiteName,
  mobileNumber,
  setMobileNumber,
  emailAddress,
  setEmailAddress,
}) => {
  const isHi = language === 'hi';

  const [tempName, setTempName] = useState(websiteName);
  const [tempMobile, setTempMobile] = useState(mobileNumber);
  const [tempEmail, setTempEmail] = useState(emailAddress);

  if (!isOpen) return null;

  const handleSave = () => {
    if (tempName) setWebsiteName(tempName);
    if (tempMobile) setMobileNumber(tempMobile);
    if (tempEmail) setEmailAddress(tempEmail);
    onClose();
  };

  const handleReset = () => {
    setTempName('Abhiyanshu & Aditya Digital Studio');
    setTempMobile('+91 78087 50089');
    setTempEmail('abhiyanshuraj146@gmail.com');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm p-4 flex items-center justify-center animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-6 shadow-2xl relative">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2 text-white font-bold text-lg">
            <Settings className="w-5 h-5 text-blue-400" />
            <span>{isHi ? 'वेबसाइट विवरण अनुकूलित करें' : 'Customize Website Details'}</span>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              {isHi ? 'वेबसाइट का नाम (Website Name):' : 'Website Name:'}
            </label>
            <input
              type="text"
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              {isHi ? 'संपर्क मोबाइल नंबर (Mobile):' : 'Mobile Number:'}
            </label>
            <input
              type="text"
              value={tempMobile}
              onChange={(e) => setTempMobile(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              {isHi ? 'ईमेल आईडी (Email):' : 'Email Address:'}
            </label>
            <input
              type="email"
              value={tempEmail}
              onChange={(e) => setTempEmail(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
            <p className="font-semibold text-blue-400">
              {isHi ? 'वेबसाइट डेवलपर:' : 'Website Developers:'}
            </p>
            <p className="text-slate-200 font-bold">Abhiyanshu Kumar & Aditya Kumar</p>
            <p className="text-[11px] text-slate-400">
              {isHi
                ? 'फुटर और "About Us" सेक्शन में स्थायी रूप से सेट किया गया है।'
                : 'Locked to Abhiyanshu Kumar & Aditya Kumar as requested.'}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            onClick={handleReset}
            className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{isHi ? 'रिसेट' : 'Reset'}</span>
          </button>

          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-blue-600/20"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isHi ? 'सेव करें' : 'Save Changes'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
