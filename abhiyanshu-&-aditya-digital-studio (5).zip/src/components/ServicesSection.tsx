import React, { useState } from 'react';
import {
  Layout,
  Briefcase,
  ShoppingBag,
  TrendingUp,
  RefreshCw,
  Globe,
  Check,
  ArrowRight,
  Sparkles,
  Phone,
} from 'lucide-react';
import { Language, Page, Service } from '../types';
import { servicesData } from '../data/websiteData';

interface ServicesSectionProps {
  language: Language;
  setCurrentPage: (page: Page) => void;
  onSelectServiceForInquiry: (serviceName: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  language,
  setCurrentPage,
  onSelectServiceForInquiry,
}) => {
  const isHi = language === 'hi';

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-6 h-6 text-blue-400" />;
      case 'Briefcase':
        return <Briefcase className="w-6 h-6 text-indigo-400" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-6 h-6 text-emerald-400" />;
      case 'TrendingUp':
        return <TrendingUp className="w-6 h-6 text-amber-400" />;
      case 'RefreshCw':
        return <RefreshCw className="w-6 h-6 text-purple-400" />;
      case 'Globe':
        return <Globe className="w-6 h-6 text-cyan-400" />;
      default:
        return <Layout className="w-6 h-6 text-blue-400" />;
    }
  };

  return (
    <div className="bg-slate-950 text-slate-100 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isHi ? 'हमारी सेवाएं (Services)' : 'Our Services'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            {isHi ? 'आपकी आवश्यकताओं के अनुसार वेब समाधान' : 'Tailored Web Solutions For Your Success'}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            {isHi
              ? 'अभियांशु कुमार और आदित्य कुमार द्वारा प्रत्येक प्रोजेक्ट को उच्च-गुणवत्ता, सुरक्षा और गति के साथ तैयार किया जाता है।'
              : 'Every website crafted by Abhiyanshu Kumar & Aditya Kumar guarantees high speed, responsive layout, and SEO compatibility.'}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesData.map((service: Service) => (
            <div
              key={service.id}
              className={`bg-slate-900 rounded-2xl p-6 border transition-all duration-300 flex flex-col justify-between relative group ${
                service.popular
                  ? 'border-blue-500 shadow-xl shadow-blue-500/10'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {service.popular && (
                <div className="absolute -top-3 right-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                  {isHi ? 'सर्वाधिक लोकप्रिय' : 'Most Popular'}
                </div>
              )}

              <div className="space-y-4">
                <div className="p-3 rounded-xl bg-slate-800 w-fit border border-slate-700">
                  {getIcon(service.iconName)}
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">
                    {isHi ? service.titleHi : service.titleEn}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    {isHi ? service.descHi : service.descEn}
                  </p>
                </div>

                {/* Features checklist */}
                <div className="space-y-2 pt-3 border-t border-slate-800">
                  <p className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                    {isHi ? 'प्रमुख विशेषताएं:' : 'Key Features:'}
                  </p>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {(isHi ? service.featuresHi : service.featuresEn).map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Price & Booking Action */}
              <div className="mt-6 pt-4 border-t border-slate-800 space-y-3">
                {service.priceRange && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">{isHi ? 'अनुमानित शुल्क:' : 'Starting Price:'}</span>
                    <span className="font-bold text-emerald-400">{service.priceRange}</span>
                  </div>
                )}

                <button
                  onClick={() => {
                    onSelectServiceForInquiry(isHi ? service.titleHi : service.titleEn);
                    setCurrentPage('contact');
                  }}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white text-xs font-semibold transition-all border border-slate-700 hover:border-blue-500 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>{isHi ? 'अभी ऑर्डर/पूछताछ करें' : 'Inquire For This Service'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Custom Order Box */}
        <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-purple-900/40 rounded-2xl p-6 sm:p-8 border border-blue-500/30 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl font-bold text-white">
              {isHi ? 'क्या आपकी कोई विशेष आवश्यकता है?' : 'Need a Customized Website Package?'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              {isHi
                ? 'अभियांशु कुमार एवं आदित्य कुमार आपकी पसंद और आवश्यकताओं के अनुसार कस्टम वेबसाइट बनाते हैं।'
                : 'Abhiyanshu Kumar & Aditya Kumar offer custom tailored website packages for your business.'}
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('contact')}
            className="shrink-0 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-600/30 flex items-center gap-2 cursor-pointer"
          >
            <Phone className="w-4 h-4" />
            <span>{isHi ? 'सीधा संपर्क करें' : 'Get Custom Quote'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
