import React from 'react';
import { Phone, Mail, MapPin, Heart, Code2 } from 'lucide-react';
import { Page, Language } from '../types';

interface FooterProps {
  setCurrentPage: (page: Page) => void;
  language: Language;
  websiteName: string;
  mobileNumber: string;
  emailAddress: string;
}

export const Footer: React.FC<FooterProps> = ({
  setCurrentPage,
  language,
  websiteName,
  mobileNumber,
  emailAddress,
}) => {
  const isHi = language === 'hi';

  const quickLinks: { id: Page; labelEn: string; labelHi: string }[] = [
    { id: 'home', labelEn: 'Home', labelHi: 'होम' },
    { id: 'about', labelEn: 'About Us', labelHi: 'हमारे बारे में' },
    { id: 'services', labelEn: 'Services', labelHi: 'सेवाएं' },
    { id: 'gallery', labelEn: 'Gallery', labelHi: 'गैलरी' },
    { id: 'contact', labelEn: 'Contact Us', labelHi: 'संपर्क करें' },
  ];

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 pt-12 pb-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8 border-b border-slate-800">
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold">
                <Code2 className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-white">{websiteName}</h2>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              {isHi
                ? 'हम एक आधुनिक, तेज़ और आकर्षक वेबसाइट बनाने का लक्ष्य रखते हैं। हमारा उद्देश्य उपयोगकर्ताओं को बेहतरीन अनुभव प्रदान करना है।'
                : 'We aim to create a modern, fast, and attractive website. Simple, secure, and mobile-friendly.'}
            </p>

            <div className="pt-2 flex flex-col space-y-1 text-xs text-slate-300">
              <p className="font-semibold text-blue-400">
                {isHi ? 'वेबसाइट डेवलपर:' : 'Lead Developers:'}
              </p>
              <p className="font-bold text-white">Abhiyanshu Kumar & Aditya Kumar</p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              {isHi ? 'मुख्य पेजेस (Pages)' : 'Website Pages'}
            </h3>
            <ul className="space-y-2 text-xs">
              {quickLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => {
                      setCurrentPage(link.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-blue-400 transition-colors cursor-pointer"
                  >
                    {isHi ? link.labelHi : link.labelEn}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Contact */}
          <div className="md:col-span-4 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              {isHi ? 'संपर्क करें (Contact)' : 'Contact Details'}
            </h3>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <a href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`} className="hover:text-white">
                  {mobileNumber}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <a href={`mailto:${emailAddress}`} className="hover:text-white break-all">
                  {emailAddress}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>Noida, Delhi NCR, India</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Mandatory Footer Text as Specified in Prompt */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-4 text-center sm:text-left">
          <p className="font-medium text-slate-300">
            © 2026 All Rights Reserved.
          </p>
          <p className="font-semibold text-slate-200">
            Developed by Abhiyanshu Kumar & Aditya Kumar.
          </p>
        </div>
      </div>
    </footer>
  );
};
