import React, { useState } from 'react';
import {
  Phone,
  Mail,
  MapPin,
  Send,
  CheckCircle2,
  Share2,
  MessageSquare,
  Clock,
  Sparkles,
  User,
} from 'lucide-react';
import { Language, ContactMessage } from '../types';

interface ContactSectionProps {
  language: Language;
  mobileNumber: string;
  emailAddress: string;
  address: string;
  preselectedService?: string;
  onSendMessage: (msg: ContactMessage) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  language,
  mobileNumber,
  emailAddress,
  address,
  preselectedService = '',
  onSendMessage,
}) => {
  const isHi = language === 'hi';

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    service: preselectedService || 'Custom Website Design',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.mobile) return;

    const newMessage: ContactMessage = {
      id: Date.now().toString(),
      name: formData.name,
      email: formData.email,
      mobile: formData.mobile,
      service: formData.service,
      message: formData.message,
      timestamp: new Date().toLocaleString(),
    };

    onSendMessage(newMessage);
    setSubmitted(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      mobile: '',
      service: 'Custom Website Design',
      message: '',
    });
    setSubmitted(false);
  };

  return (
    <div className="bg-slate-950 text-slate-100 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{isHi ? 'संपर्क करें (Contact Us)' : 'Contact Us'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            {isHi ? 'अपनी वेबसाइट बनवाने हेतु संपर्क करें' : 'Get In Touch For Website Development'}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            {isHi
              ? 'अभियांशु कुमार और आदित्य कुमार आपकी आवश्यकताओं के अनुसार श्रेष्ठ वेबसाइट समाधान प्रदान करने हेतु तैयार हैं।'
              : 'Abhiyanshu Kumar & Aditya Kumar are here to help you turn your web ideas into reality.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Direct Contact Info & Socials */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 space-y-6 shadow-xl">
              <h3 className="text-xl font-bold text-white border-b border-slate-800 pb-3 flex items-center justify-between">
                <span>{isHi ? 'संपर्क विवरण (Contact Details)' : 'Contact Details'}</span>
                <Sparkles className="w-4 h-4 text-amber-400" />
              </h3>

              <div className="space-y-5">
                {/* Mobile Call */}
                <a
                  href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`}
                  className="flex items-start gap-4 p-3.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors group"
                >
                  <div className="p-2.5 rounded-xl bg-blue-600/20 text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      {isHi ? 'मोबाइल नंबर (Mobile)' : 'Mobile Phone'}
                    </p>
                    <p className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                      {mobileNumber}
                    </p>
                    <p className="text-[11px] text-emerald-400 mt-0.5">
                      {isHi ? 'डायरेक्ट कॉल या व्हाट्सऐप उपलब्ध' : 'Direct Call & WhatsApp Available'}
                    </p>
                  </div>
                </a>

                {/* Email */}
                <a
                  href={`mailto:${emailAddress}`}
                  className="flex items-start gap-4 p-3.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors group"
                >
                  <div className="p-2.5 rounded-xl bg-indigo-600/20 text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      {isHi ? 'ईमेल आईडी (Email)' : 'Email Address'}
                    </p>
                    <p className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors break-all">
                      {emailAddress}
                    </p>
                  </div>
                </a>

                {/* Address */}
                <div className="flex items-start gap-4 p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                  <div className="p-2.5 rounded-xl bg-purple-600/20 text-purple-400">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      {isHi ? 'पता (Address)' : 'Location Address'}
                    </p>
                    <p className="text-xs font-medium text-slate-200 mt-1 leading-relaxed">
                      {address}
                    </p>
                  </div>
                </div>

                {/* Developers Attribution Tag */}
                <div className="p-4 rounded-xl bg-blue-950/40 border border-blue-500/20 text-xs text-blue-300 flex items-center gap-3">
                  <User className="w-5 h-5 text-blue-400 shrink-0" />
                  <div>
                    <p className="font-bold">
                      {isHi ? 'वेब डेवलपर टीम:' : 'Web Developers:'}
                    </p>
                    <p className="text-slate-200 font-semibold">
                      Abhiyanshu Kumar & Aditya Kumar
                    </p>
                  </div>
                </div>
              </div>

              {/* Working Hours & Social Links */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>
                    {isHi ? 'सोमवार - शनिवार: 9:00 AM - 8:00 PM' : 'Mon - Sat: 9:00 AM - 8:00 PM IST'}
                  </span>
                </div>

                <div className="pt-2">
                  <p className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
                    <Share2 className="w-3.5 h-3.5 text-blue-400" />
                    <span>{isHi ? 'सोशल मीडिया लिंक्स' : 'Social Media Links'}</span>
                  </p>
                  <div className="flex items-center gap-3">
                    <a
                      href={`https://wa.me/${mobileNumber.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition-colors cursor-pointer"
                    >
                      WhatsApp
                    </a>
                    <a
                      href="https://linkedin.com"
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-600 text-white text-xs font-medium transition-colors cursor-pointer"
                    >
                      LinkedIn
                    </a>
                    <a
                      href="https://github.com"
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors cursor-pointer"
                    >
                      GitHub
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-xl relative">
              {submitted ? (
                <div className="text-center py-12 space-y-4 animate-in zoom-in-95">
                  <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    {isHi ? 'धन्यवाद! आपका संदेश प्राप्त हुआ।' : 'Thank You! Message Received.'}
                  </h3>
                  <p className="text-slate-300 text-sm max-w-md mx-auto leading-relaxed">
                    {isHi
                      ? 'अभियांशु कुमार और आदित्य कुमार शीघ्र ही आपसे संपर्क करेंगे।'
                      : 'Abhiyanshu Kumar & Aditya Kumar will contact you shortly regarding your website inquiry.'}
                  </p>
                  <button
                    onClick={resetForm}
                    className="mt-4 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    {isHi ? 'दूसरा संदेश भेजें' : 'Send Another Message'}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <h3 className="text-xl font-bold text-white">
                      {isHi ? 'ऑनलाइन पूछताछ फ़ॉर्म' : 'Online Website Inquiry Form'}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      {isHi
                        ? 'कृपया नीचे दी गई जानकारी भरें। हम जल्द ही आपसे संपर्क करेंगे।'
                        : 'Please fill in your details below for a quick quote.'}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Full Name */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {isHi ? 'आपका नाम *' : 'Your Full Name *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder={isHi ? 'उदा: राहुल शर्मा' : 'e.g. Rahul Sharma'}
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    {/* Mobile Number */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {isHi ? 'मोबाइल नंबर *' : 'Mobile Phone Number *'}
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.mobile}
                        onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                        placeholder={isHi ? 'उदा: +91 98765 43210' : 'e.g. +91 98765 43210'}
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Email */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {isHi ? 'ईमेल आईडी' : 'Email Address'}
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="your@email.com"
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    {/* Service Required */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        {isHi ? 'आवश्यक सेवा (Service Required)' : 'Required Service'}
                      </label>
                      <select
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
                      >
                        <option value="Custom Website Design">
                          {isHi ? 'कस्टम वेबसाइट डिज़ाइन' : 'Custom Website Design'}
                        </option>
                        <option value="Business Portfolio Website">
                          {isHi ? 'बिजनेस और पोर्टफोलियो वेबसाइट' : 'Business & Portfolio Website'}
                        </option>
                        <option value="E-Commerce Store">
                          {isHi ? 'ई-कॉमर्स और ऑनलाइन स्टोर' : 'E-Commerce Online Store'}
                        </option>
                        <option value="SEO & Speed Optimization">
                          {isHi ? 'एसईओ और स्पीड ऑप्टिमाइज़ेशन' : 'SEO & Speed Optimization'}
                        </option>
                        <option value="Website Redesign">
                          {isHi ? 'वेबसाइट रिडिज़ाइन' : 'Website Redesign'}
                        </option>
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {isHi ? 'प्रोजेक्ट विवरण / संदेश' : 'Message / Project Details'}
                    </label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder={
                        isHi
                          ? 'अपनी वेबसाइट की आवश्यकताओं के बारे में विस्तार से बताएं...'
                          : 'Describe your website requirements...'
                      }
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isHi ? 'संदेश भेजें' : 'Send Inquiry Message'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
