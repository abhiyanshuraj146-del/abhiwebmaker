import React, { useState } from 'react';
import { Globe, Menu, X, Phone, Code2, Sparkles } from 'lucide-react';
import { Page, Language } from '../types';

interface NavbarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  websiteName: string;
  mobileNumber: string;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  setCurrentPage,
  language,
  setLanguage,
  websiteName,
  mobileNumber,
  onOpenSettings,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: Page; labelEn: string; labelHi: string }[] = [
    { id: 'home', labelEn: 'Home', labelHi: 'होम' },
    { id: 'about', labelEn: 'About Us', labelHi: 'हमारे बारे में' },
    { id: 'services', labelEn: 'Services', labelHi: 'सेवाएं' },
    { id: 'gallery', labelEn: 'Gallery', labelHi: 'गैलरी' },
    { id: 'contact', labelEn: 'Contact Us', labelHi: 'संपर्क करें' },
  ];

  const handleNavClick = (page: Page) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-lg">
      {/* Top Notification Bar */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 text-xs py-1.5 px-4 text-center text-white/90 font-medium flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-2 mx-auto sm:mx-0">
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
          <span>
            {language === 'hi'
              ? 'अभियांशु कुमार और आदित्य कुमार द्वारा विकसित आधुनिक वेबसाइट'
              : 'Modern Web Solutions Developed by Abhiyanshu Kumar & Aditya Kumar'}
          </span>
        </div>

        <div className="hidden sm:flex items-center gap-4 text-xs">
          <button
            onClick={onOpenSettings}
            className="hover:underline text-amber-300 font-semibold cursor-pointer"
          >
            {language === 'hi' ? 'नाम/विवरण बदलें' : 'Customize Site Details'}
          </button>
          <a
            href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`}
            className="flex items-center gap-1 hover:text-amber-300 transition-colors"
          >
            <Phone className="w-3 h-3" />
            <span>{mobileNumber}</span>
          </a>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Code2 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent leading-tight">
                {websiteName}
              </h1>
              <p className="text-[11px] text-blue-400 font-medium">
                {language === 'hi' ? 'अभियांशु व आदित्य' : 'By Abhiyanshu & Aditya'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-800/60 p-1 rounded-full border border-slate-700/60">
            {navItems.map((item) => {
              const active = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all cursor-pointer ${
                    active
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-semibold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  {language === 'hi' ? item.labelHi : item.labelEn}
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="hidden md:flex items-center gap-3">
            {/* Language Switcher Button */}
            <button
              onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
              title="Toggle Hindi/English Language"
            >
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span>{language === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* Direct Call CTA */}
            <a
              href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-blue-600/20 transition-all hover:shadow-lg cursor-pointer"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'कॉल करें' : 'Call Now'}</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
              className="px-2.5 py-1 rounded-md bg-slate-800 text-xs font-semibold text-blue-400 border border-slate-700"
            >
              {language === 'hi' ? 'EN' : 'हिंदी'}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-2">
          {navItems.map((item) => {
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {language === 'hi' ? item.labelHi : item.labelEn}
              </button>
            );
          })}

          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <a
              href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-blue-600 text-white font-medium text-sm shadow-md"
            >
              <Phone className="w-4 h-4" />
              <span>{mobileNumber}</span>
            </a>
            <button
              onClick={() => {
                onOpenSettings();
                setMobileMenuOpen(false);
              }}
              className="w-full text-center py-2 text-xs text-amber-400 hover:underline"
            >
              {language === 'hi' ? 'वेबसाइट विवरण बदलें' : 'Customize Details'}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
