import React from 'react';
import {
  Code2,
  ShieldCheck,
  Zap,
  Smartphone,
  CheckCircle,
  Github,
  Linkedin,
  Mail,
  Award,
} from 'lucide-react';
import { Language, Page } from '../types';
import { developers, aboutUsText } from '../data/websiteData';

interface AboutSectionProps {
  language: Language;
  setCurrentPage: (page: Page) => void;
  websiteName: string;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  language,
  setCurrentPage,
  websiteName,
}) => {
  const isHi = language === 'hi';
  const text = isHi ? aboutUsText.hi : aboutUsText.en;

  const coreValues = [
    {
      icon: <Zap className="w-6 h-6 text-amber-500" />,
      titleEn: 'Fast Loading & High Speed',
      titleHi: 'फास्ट लोडिंग स्पीड',
      descEn: 'Optimized code execution ensuring sub-second page loads and zero lag.',
      descHi: 'त्वरित लोडिंग और बिना किसी रुकावट के बेहतरीन परफॉरमेंस।',
    },
    {
      icon: <Smartphone className="w-6 h-6 text-emerald-500" />,
      titleEn: 'Mobile-Friendly Responsive Layout',
      titleHi: 'मोबाइल-फ्रेंडली डिज़ाइन',
      descEn: 'Pixel-perfect display across smartphones, tablets, and desktop displays.',
      descHi: 'सभी मोबाइल, टैबलेट और कंप्यूटर स्क्रीन पर सटीक और सुंदर लेआउट।',
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-blue-500" />,
      titleEn: 'Simple & Secure Architecture',
      titleHi: 'सरल और सुरक्षित व्यवस्था',
      descEn: 'Clean, reliable, and secure code protecting user privacy and data.',
      descHi: 'सुरक्षित कोड और साफ़-सुथरा डिज़ाइन जो उपयोगकर्ताओं का विश्वास जीतता है।',
    },
  ];

  return (
    <div className="bg-slate-900 text-slate-100 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider">
            <Award className="w-3.5 h-3.5" />
            <span>{isHi ? 'हमारे बारे में (About Us)' : 'About Us'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            {isHi ? 'विश्वास और आधुनिकता का संगम' : 'Building Trust Through Modern Web Design'}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            {isHi
              ? 'डिजिटल दुनिया में आपके व्यवसाय को एक सशक्त और आकर्षक पहचान दिलाने के लिए प्रतिबद्ध।'
              : 'Empowering your digital presence with high-performance, attractive web design.'}
          </p>
        </div>

        {/* Featured Banner with User's Exact About Us Text */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-800/80 rounded-2xl p-6 sm:p-10 border border-slate-700/80 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                <Code2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{websiteName}</h3>
                <p className="text-xs text-blue-400 font-medium">
                  {isHi ? 'डेवलपर अभियान्शु कुमार एवं आदित्य कुमार' : 'Developers: Abhiyanshu Kumar & Aditya Kumar'}
                </p>
              </div>
            </div>

            {/* Exact Prompt Paragraph Highlight */}
            <div className="p-5 sm:p-6 rounded-xl bg-slate-900/90 border border-blue-500/30 text-slate-200 text-base sm:text-lg leading-relaxed shadow-inner">
              <p className="font-medium text-slate-100 italic">
                "{text.main}"
              </p>
            </div>

            {/* Mission & Vision Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-700/60">
                <h4 className="text-lg font-bold text-blue-300 mb-2">{text.missionTitle}</h4>
                <p className="text-sm text-slate-300 leading-relaxed">{text.missionDesc}</p>
              </div>

              <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-700/60">
                <h4 className="text-lg font-bold text-indigo-300 mb-2">{text.visionTitle}</h4>
                <p className="text-sm text-slate-300 leading-relaxed">{text.visionDesc}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Developer Profiles Section */}
        <div className="space-y-8">
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-bold text-white">
              {isHi ? 'वेबसाइट डेवलपर टीम' : 'Meet the Developers'}
            </h3>
            <p className="text-sm text-slate-400">
              {isHi
                ? 'अभियांशु कुमार और आदित्य कुमार के मार्गदर्शन में तैयार'
                : 'Crafted with expertise by Abhiyanshu Kumar & Aditya Kumar'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {developers.map((dev, idx) => (
              <div
                key={idx}
                className="bg-slate-800/80 rounded-2xl p-6 border border-slate-700 hover:border-blue-500/50 transition-all shadow-lg flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <img
                      src={dev.avatar}
                      alt={dev.name}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500/40 shadow-md"
                    />
                    <div>
                      <h4 className="text-xl font-bold text-white">{dev.name}</h4>
                      <p className="text-xs font-semibold text-blue-400">
                        {isHi ? dev.roleHi : dev.role}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {isHi ? 'सह-संस्थापक एवं वेब डेवलपर' : 'Co-Founder & Web Developer'}
                      </p>
                    </div>
                  </div>

                  <p className="text-sm text-slate-300 leading-relaxed">
                    {isHi ? dev.bioHi : dev.bio}
                  </p>

                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      {isHi ? 'मुख्य कौशल (Skills)' : 'Core Skills'}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {dev.skills.map((skill, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-700 text-xs font-medium text-slate-200"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-700/80 flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" />
                    {isHi ? 'उपलब्ध प्रोजेक्ट्स हेतु' : 'Available for Projects'}
                  </span>

                  <div className="flex items-center gap-3">
                    <a
                      href={dev.github}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-700 text-slate-300 transition-colors"
                      aria-label={`${dev.name} GitHub`}
                    >
                      <Github className="w-4 h-4" />
                    </a>
                    <a
                      href={dev.linkedin}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-700 text-blue-400 transition-colors"
                      aria-label={`${dev.name} LinkedIn`}
                    >
                      <Linkedin className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Core Values Grid */}
        <div className="space-y-6">
          <h3 className="text-xl font-bold text-white text-center">
            {isHi ? 'हमारी वेब डिज़ाइन प्राथमिकताएं' : 'Our Core Development Pillars'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {coreValues.map((val, idx) => (
              <div
                key={idx}
                className="bg-slate-800/40 p-6 rounded-xl border border-slate-700/60 space-y-3"
              >
                <div className="p-2.5 rounded-lg bg-slate-900 w-fit">{val.icon}</div>
                <h4 className="text-lg font-semibold text-white">
                  {isHi ? val.titleHi : val.titleEn}
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isHi ? val.descHi : val.descEn}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center pt-6">
          <button
            onClick={() => setCurrentPage('contact')}
            className="px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
          >
            {isHi ? 'अपनी वेबसाइट बनवाने हेतु संपर्क करें' : 'Get Your Custom Website Designed'}
          </button>
        </div>
      </div>
    </div>
  );
};
