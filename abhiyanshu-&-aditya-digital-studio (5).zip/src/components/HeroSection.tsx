import React from 'react';
import {
  Smartphone,
  Zap,
  Mail,
  Share2,
  Image as ImageIcon,
  SearchCheck,
  ArrowRight,
  CheckCircle2,
  Phone,
  Code,
  ShieldCheck,
} from 'lucide-react';
import { Page, Language } from '../types';

interface HeroSectionProps {
  setCurrentPage: (page: Page) => void;
  language: Language;
  websiteName: string;
  mobileNumber: string;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  setCurrentPage,
  language,
  websiteName,
  mobileNumber,
}) => {
  const isHi = language === 'hi';

  const featureBadges = [
    {
      icon: <Smartphone className="w-4 h-4 text-emerald-400" />,
      labelEn: 'Responsive Design (Mobile & PC)',
      labelHi: 'रिस्पॉन्सिव डिज़ाइन (मोबाइल और पीसी)',
    },
    {
      icon: <Zap className="w-4 h-4 text-amber-400" />,
      labelEn: 'Fast Loading Speed',
      labelHi: 'फास्ट लोडिंग स्पीड',
    },
    {
      icon: <Mail className="w-4 h-4 text-blue-400" />,
      labelEn: 'Interactive Contact Form',
      labelHi: 'कांटैक्ट फॉर्म',
    },
    {
      icon: <Share2 className="w-4 h-4 text-purple-400" />,
      labelEn: 'Social Media Links',
      labelHi: 'सोशल मीडिया लिंक्स',
    },
    {
      icon: <ImageIcon className="w-4 h-4 text-rose-400" />,
      labelEn: 'Photo Gallery',
      labelHi: 'फोटो गैलरी',
    },
    {
      icon: <SearchCheck className="w-4 h-4 text-cyan-400" />,
      labelEn: 'SEO Friendly',
      labelHi: 'एसईओ फ्रेंडली',
    },
  ];

  return (
    <section className="relative overflow-hidden bg-slate-950 text-white py-16 lg:py-24 border-b border-slate-800">
      {/* Subtle Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Main Hero Copy */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Developer Credit Tagline */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-900/40 border border-blue-700/50 text-blue-300 text-xs sm:text-sm font-semibold shadow-inner">
              <Code className="w-4 h-4 text-blue-400" />
              <span>
                {isHi
                  ? 'डेवलप्ड बाय: अभियान्शु कुमार एवं आदित्य कुमार'
                  : 'Developed By: Abhiyanshu Kumar & Aditya Kumar'}
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight">
              {isHi ? (
                <>
                  आधुनिक, तेज़ और <br />
                  <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                    आकर्षक वेबसाइट समाधान
                  </span>
                </>
              ) : (
                <>
                  Modern, Fast & <br />
                  <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                    Attractive Web Solutions
                  </span>
                </>
              )}
            </h1>

            {/* Subheading / About Summary */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto lg:mx-0">
              {isHi
                ? 'हमारा उद्देश्य उपयोगकर्ताओं को बेहतरीन अनुभव और उपयोगी जानकारी प्रदान करना है। आपकी वेबसाइट को सरल, सुरक्षित और पूर्ण रूप से मोबाइल-फ्रेंडली बनाया जाएगा।'
                : 'Our goal is to provide users with the best experience and useful information. We build simple, highly secure, and 100% mobile-friendly websites for your growth.'}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => setCurrentPage('services')}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-xl shadow-blue-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.02] cursor-pointer"
              >
                <span>{isHi ? 'हमारी सेवाएं देखें' : 'Explore Services'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setCurrentPage('contact')}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm border border-slate-700 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Phone className="w-4 h-4 text-blue-400" />
                <span>{isHi ? 'संपर्क करें' : 'Contact Us'}</span>
              </button>
            </div>

            {/* Verified Guarantees */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isHi ? '100% सुरक्षित कोड' : '100% Secure Code'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>{isHi ? 'गूगल एसईओ रेडी' : 'Google SEO Ready'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>{isHi ? 'सुपरफास्ट लोडिंग' : 'Superfast Load Time'}</span>
              </div>
            </div>
          </div>

          {/* Feature Highlight Grid Card */}
          <div className="lg:col-span-5">
            <div className="bg-slate-900/90 rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-2xl relative">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
                <div>
                  <h2 className="text-lg font-bold text-white">
                    {isHi ? 'वेबसाइट की प्रमुख विशेषताएं' : 'Key Website Features'}
                  </h2>
                  <p className="text-xs text-slate-400">
                    {isHi ? 'हमारे द्वारा निर्मित हर वेबसाइट में शामिल' : 'Included in every website we build'}
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
                  {isHi ? 'रेडी टू डिप्लॉय' : 'Ready to Deploy'}
                </span>
              </div>

              {/* Grid of feature badges */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {featureBadges.map((badge, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 transition-colors"
                  >
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-700">
                      {badge.icon}
                    </div>
                    <span className="text-xs font-medium text-slate-200">
                      {isHi ? badge.labelHi : badge.labelEn}
                    </span>
                  </div>
                ))}
              </div>

              {/* Developer Attribution Card Footer */}
              <div className="mt-6 pt-4 border-t border-slate-800 bg-slate-950/60 -mx-6 -mb-6 p-6 rounded-b-2xl flex items-center justify-between">
                <div>
                  <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                    {isHi ? 'वेब डिज़ाइनर एवं डेवलपर' : 'Lead Developers'}
                  </p>
                  <p className="text-sm font-bold text-blue-300">
                    Abhiyanshu Kumar & Aditya Kumar
                  </p>
                </div>
                <a
                  href={`tel:${mobileNumber.replace(/[^0-9+]/g, '')}`}
                  className="px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 text-xs font-semibold border border-blue-500/30 transition-colors"
                >
                  {isHi ? 'डायरेक्ट कॉल' : 'Direct Call'}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
