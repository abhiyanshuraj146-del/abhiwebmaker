export type Page = 'home' | 'about' | 'services' | 'gallery' | 'contact';

export type Language = 'hi' | 'en';

export interface Developer {
  name: string;
  role: string;
  roleHi: string;
  bio: string;
  bioHi: string;
  skills: string[];
  avatar: string;
  github?: string;
  linkedin?: string;
}

export interface Service {
  id: string;
  titleEn: string;
  titleHi: string;
  descEn: string;
  descHi: string;
  iconName: string;
  featuresEn: string[];
  featuresHi: string[];
  priceRange?: string;
  popular?: boolean;
}

export interface GalleryItem {
  id: string;
  titleEn: string;
  titleHi: string;
  category: 'web' | 'mobile' | 'ui' | 'branding';
  categoryLabelEn: string;
  categoryLabelHi: string;
  image: string;
  descriptionEn: string;
  descriptionHi: string;
  tags: string[];
}

export interface ContactInfo {
  mobile: string;
  email: string;
  addressEn: string;
  addressHi: string;
  whatsapp: string;
  developer1: string;
  developer2: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  mobile: string;
  service: string;
  message: string;
  timestamp: string;
}
